package com.ad.statussaver;

public enum AdError {
}
