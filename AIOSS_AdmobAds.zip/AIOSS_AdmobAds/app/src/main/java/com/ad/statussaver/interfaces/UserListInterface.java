package com.ad.statussaver.interfaces;


import com.ad.statussaver.model.FBStoryModel.NodeModel;
import com.ad.statussaver.model.story.TrayModel;

public interface UserListInterface {
    void userListClick(int position, TrayModel trayModel);
    void fbUserListClick(int position, NodeModel trayModel);
}
